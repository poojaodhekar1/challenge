/**
 * This javascript file will constitute the entry point of your solution.
 *
 * Edit it as you need.  It currently contains things that you might find helpful to get started.
 */

// This is not really required, but means that changes to index.html will cause a reload.
//require('./site/index.html')
require('./site/index.html')
// Apply the styles in style.css to the page.
require('./site/style.css')

// if you want to use es6, you can do something like
//     require('./es6/myEs6code')
// here to load the myEs6code.js file, and it will be automatically transpiled.

// Change this to get detailed logging from the stomp library
global.DEBUG = false

const url = "ws://localhost:8011/stomp"
const client = Stomp.client(url)
client.debug = function(msg) {
  if (global.DEBUG) {
    console.info(msg)
  }
}
//To check whether the currency pair is exist in currency array or not
Array.prototype.inArray = function(comparer) { 
    for(var i=0; i < this.length; i++) { 
        if(comparer(this[i])) return true; 
    }
    return false; 
}; 

// adds an element to the array if it does not already exist using a comparer 
// function
Array.prototype.pushIfNotExist = function(element, comparer) { 
    if (!this.inArray(comparer)) {
        this.push(element);
        
    }
}; 

const array_lastChangeBid = [];

//This function accepts data from server and displays on client screen(Browser)
const connectCallback = function(x) 
{
    id = client.subscribe("/fx/prices", function(d) {
		const jsondata = JSON.parse(d.body);
		array_lastChangeBid.push(jsondata.lastChangeBid);

		if(jsondata!='')
        {
			//to draw a sparkline for each last bid changed.
			var sparkline = new Sparkline(document.getElementById("example-sparkline"));
			sparkline.draw(array_lastChangeBid);

        	var rowCount= $('#table').find('tr').length;

        	const row = document.createElement('tr');  // create row node
			const col = document.createElement('td');  // create column node for currencypair name
			const col2 = document.createElement('td'); // create second column node bestBid
			const col3 = document.createElement('td'); // create third column node bestAsk
			const col4 = document.createElement('td'); // create fourth column node openBid
			const col5 = document.createElement('td'); // create fifth column node openAsk
			const col6 = document.createElement('td'); // create sixth column node lastChangeAsk
			const col7 = document.createElement('td'); // create seventh column node lastChangeBid

        	if (rowCount==1) {
        		row.appendChild(col); // append first column to row(currencypair name)
				row.appendChild(col2); // append second column to row(bestBid)
				row.appendChild(col3); // append third column to row(bestAsk)
				row.appendChild(col4); // append fourth column to row(openBid)
				row.appendChild(col5); // append fifth column to row(openAsk)
				row.appendChild(col6); // append sixth column to row(lastChangeAsk)
				row.appendChild(col7); // append seventh column to row(lastChangeBid)
								
				col.innerHTML = jsondata.name; // put data in first column
				col2.innerHTML = jsondata.bestBid; // put data in second column
				col3.innerHTML = jsondata.bestAsk; // put data in second column
				col4.innerHTML = jsondata.openBid; // put data in second column
				col5.innerHTML = jsondata.openAsk; // put data in second column
				col6.innerHTML = jsondata.lastChangeAsk; // put data in second column
				col7.innerHTML = jsondata.lastChangeBid; // put data in second column
								
				var table = document.getElementById("tbody"); // find table to append to
				table.appendChild(row); //To append the row to table.
        	}
        	else{
        		$('#table').find('tr').each(function(){
        			const currency_name= $('#table tr').find('td').first().text();
        			if (currency_name==jsondata.name) {
        				col6.innerHTML = jsondata.lastChangeAsk; // put data in second column
						col7.innerHTML = jsondata.lastChangeBid;
						
        			}
        			else
        			{
        				row.appendChild(col); // append first column to row(currencypair name)
						row.appendChild(col2); // append second column to row(bestBid)
						row.appendChild(col3); // append third column to row(bestAsk)
						row.appendChild(col4); // append fourth column to row(openBid)
						row.appendChild(col5); // append fifth column to row(openAsk)
						row.appendChild(col6); // append sixth column to row(lastChangeAsk)
						row.appendChild(col7); // append seventh column to row(lastChangeBid)
										
						col.innerHTML = jsondata.name; // put data in first column
						col2.innerHTML = jsondata.bestBid; // put data in second column
						col3.innerHTML = jsondata.bestAsk; // put data in second column
						col4.innerHTML = jsondata.openBid; // put data in second column
						col5.innerHTML = jsondata.openAsk; // put data in second column
						col6.innerHTML = jsondata.lastChangeAsk; // put data in second column
						col7.innerHTML = jsondata.lastChangeBid; // put data in second column
										
						const table = document.getElementById("tbody"); // find table to append to
						table.appendChild(row); //To append the row to table.
					
						
        			}

        		});
        	}
        }
	});	 
};

			
client.connect({}, connectCallback, function(error) {
  alert(error.headers.message)
})


